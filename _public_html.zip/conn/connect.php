<?php
$db_name = 'mysql:host=localhost;dbname=u875102609_1';
// $user_name = 'u712167659_lucho';
$user_name = 'u875102609_1';
// $user_password = 'unambaA1_';
$user_password = 'unambaA1_';
$conn = new PDO($db_name, $user_name, $user_password);
